var categories = [
  {
    id: 0,
    value: 'value',
  },
  {
    id: 1,
    value: 'value',
  },
  {
    id: 2,
    value: 'value',
  },
  {
    id: 3,
    value: 'value',
  }
]

function addCategories(category) {
  categories.push(category);
}

function getCategories() {
  return categories;
}

function deleteCategories(id) {
  //var arr2 = ["Matheus", "João", "Pedro", "Ricardo"];
  var indice = categories.indexOf();
console.log(indice)
  //arr2.splice(indice, 1);

  return categories;
}

function getCategorieById(id) {
  return id;
}

exports.addCategories = addCategories;
exports.getCategories = getCategories;
exports.deleteCategories = deleteCategories;
exports.getCategorieById = getCategorieById;

